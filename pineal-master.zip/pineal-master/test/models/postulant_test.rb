require 'test_helper'

class PostulantTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
