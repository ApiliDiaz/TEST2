require 'test_helper'

class VicepresidencyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
