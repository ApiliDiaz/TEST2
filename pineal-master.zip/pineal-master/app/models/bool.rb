class Bool < ApplicationRecord
end
