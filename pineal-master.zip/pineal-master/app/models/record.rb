class Record < ApplicationRecord
end
