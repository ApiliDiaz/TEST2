class Origin < ApplicationRecord
    has_many :postulants
end
