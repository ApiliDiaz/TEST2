module OriginsHelper
end
